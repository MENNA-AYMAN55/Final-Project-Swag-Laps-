import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginHappyTest {
    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
    }

    @Test
    public void TC10_validLogin() {
        login("standard_user", "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "Login failed with valid credentials.");
    }

    @Test
    public void TC11_invalidUsername_validPassword() {
        login("invalid_user", "secret_sauce");
        assertErrorContains("Username and password do not match any user in this service");
    }

    @Test
    public void TC12_validUsername_invalidPassword() {
        login("standard_user", "wrong_password");
        assertErrorContains("Username and password do not match any user in this service");
    }

    @Test
    public void TC13_emptyUsernameAndPassword() {
        login("", "");
        assertErrorContains("Username is required");
    }

    @Test
    public void TC14_lockedOutUser() {
        login("locked_out_user", "secret_sauce");
        assertErrorContains("Sorry, this user has been locked out.");
    }

    @Test
    public void TC15_problemUserLogin() {
        login("problem_user", "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "Login failed for problem_user.");
    }

    @Test
    public void TC16_performanceGlitchUserLogin() {
        login("performance_glitch_user", "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "Login failed for performance_glitch_user.");
    }

    private void login(String username, String password) {
        WebElement usernameField = driver.findElement(By.id("user-name"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("login-button"));

        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
        loginButton.click();
    }

    private void assertErrorContains(String expectedMessage) {
        WebElement errorMessage = driver.findElement(By.cssSelector("h3[data-test='error']"));
        Assert.assertTrue(errorMessage.getText().contains(expectedMessage),
                "Expected error message not found. Actual: " + errorMessage.getText());
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
