import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class InvalidLoginTest {
    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
    }

    // Invalid Username and valid Password
    @Test
    public void TC11_invalidUsername_validPassword() {
        login("invalid_user", "secret_sauce");
        assertErrorContains("Username and password do not match any user in this service");
    }

    // Valid Username and invalid Password
    @Test
    public void TC12_validUsername_invalidPassword() {
        login("standard_user", "wrong_password");
        assertErrorContains("Username and password do not match any user in this service");
    }

    // Empty Username and Empty Password
    @Test
    public void TC13_emptyUsernameAndPassword() {
        login("", "");
        assertErrorContains("Username is required");
    }

    // Locked Out User
    @Test
    public void TC14_lockedOutUser() {
        login("locked_out_user", "secret_sauce");
        assertErrorContains("Sorry, this user has been locked out.");
    }

    // Problem User
    @Test
    public void TC15_problemUserLogin() {
        login("problem_user", "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "Login failed for problem_user.");
    }

    // Performance Glitch User
    @Test
    public void TC16_performanceGlitchUserLogin() {
        login("performance_glitch_user", "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "Login failed for performance_glitch_user.");
    }

    // Invalid Username with special characters
    @Test
    public void TC17_invalidUsernameWithSpecialChars() {
        login("invalid@user", "secret_sauce");
        assertErrorContains("Username and password do not match any user in this service");
    }

    // Invalid Password with special characters
    @Test
    public void TC18_invalidPasswordWithSpecialChars() {
        login("standard_user", "wrong@password!");
        assertErrorContains("Username and password do not match any user in this service");
    }

    // Empty Password
    @Test
    public void TC19_emptyPassword() {
        login("standard_user", "");
        assertErrorContains("Password is required");
    }

    // Invalid Password with whitespaces
    @Test
    public void TC20_invalidPasswordWithWhitespaces() {
        login("standard_user", " wrong_password ");
        assertErrorContains("Username and password do not match any user in this service");
    }

    // Username Length below Minimum limit
    @Test
    public void TC21_usernameLengthBelowMinLimit() {
        login("a", "secret_sauce");
        assertErrorContains("Username must be at least 3 characters long");
    }

    // Password Length below Minimum limit
    @Test
    public void TC22_passwordLengthBelowMinLimit() {
        login("standard_user", "ab");
        assertErrorContains("Password must be at least 6 characters long");
    }

    // Non-existent page error
    @Test
    public void TC23_nonExistentPage() {
        login("standard_user", "secret_sauce");
        driver.get("https://www.saucedemo.com/nonexistentpage");
        Assert.assertTrue(driver.getCurrentUrl().contains("404"), "Page does not exist");
    }

    // Missing product title after login
    @Test
    public void TC24_missingProductTitle() {
        login("standard_user", "secret_sauce");
        WebElement productTitle = driver.findElement(By.className("product_label"));
        Assert.assertNotNull(productTitle, "Product title is not displayed");
    }

    // Forgot password link visibility
    @Test
    public void TC25_forgotPasswordLink() {
        WebElement forgotPasswordLink = driver.findElement(By.linkText("Forgot your password?"));
        Assert.assertTrue(forgotPasswordLink.isDisplayed(), "Forgot password link is not displayed");
    }

    // Register button visibility
    @Test
    public void TC26_registrationPage() {
        WebElement registerButton = driver.findElement(By.linkText("Create an account"));
        Assert.assertTrue(registerButton.isDisplayed(), "Register button is not displayed");
    }

    private void login(String username, String password) {
        WebElement usernameField = driver.findElement(By.id("user-name"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.id("login-button"));

        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
        loginButton.click();
    }

    private void assertErrorContains(String expectedMessage) {
        WebElement errorMessage = driver.findElement(By.cssSelector("h3[data-test='error']"));
        Assert.assertTrue(errorMessage.getText().contains(expectedMessage),
                "Expected error message not found. Actual: " + errorMessage.getText());
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
