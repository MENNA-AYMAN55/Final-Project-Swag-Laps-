import org.dataloader.Try;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import java.net.URL;
import java.util.List;
public class Main {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "c:\\windows\\chromedriver-win64\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://www.saucedemo.com/v1/index.html");
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        driver.findElement(By.className("inventory_item_name")).click();
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        // 4. إضافة المنتج للسلة
        driver.findElement(By.className("btn_primary")).click();
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        // 5. فتح السلة
        driver.findElement(By.className("shopping_cart_link")).click();
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        // 6. Checkout
        driver.findElement(By.className("checkout_button")).click();
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        //
        driver.findElement(By.id("first-name")).sendKeys("mazen");
        driver.findElement(By.id("last-name")).sendKeys("hatem");
        driver.findElement(By.id("postal-code")).sendKeys("3753450");
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driver.findElement(By.className("cart_button")).click();
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        // 8. Finish
        driver.findElement(By.className("cart_button")).click();
        try {
            Thread.sleep(5000);

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        finally {
            driver.quit();
        }



    }
}

